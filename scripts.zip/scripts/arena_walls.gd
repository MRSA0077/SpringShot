extends StaticBody3D
## Builds four boundary walls around the arena (collision + visible red surface).
## Turn on Auto Fit to size and place them from the "Arena" node automatically.

@export var auto_fit: bool = true
@export var arena_size: Vector2 = Vector2(40.0, 40.0)  # full width (X) and depth (Z)
@export var wall_height: float = 20.0
@export var wall_thickness: float = 2.0
@export var show_walls: bool = true
@export var wall_color: Color = Color(0.9, 0.1, 0.1, 1.0)   # red; lower alpha for see-through

func _ready() -> void:
	collision_layer = 1
	collision_mask = 1
	if auto_fit:
		_fit_to_arena()
	var hx: float = arena_size.x * 0.5
	var hz: float = arena_size.y * 0.5
	var t: float = wall_thickness
	var y: float = wall_height * 0.5
	_add_wall("WallNorth", Vector3(0.0, y, -hz - t * 0.5), Vector3(arena_size.x + t * 2.0, wall_height, t))
	_add_wall("WallSouth", Vector3(0.0, y, hz + t * 0.5), Vector3(arena_size.x + t * 2.0, wall_height, t))
	_add_wall("WallEast", Vector3(hx + t * 0.5, y, 0.0), Vector3(t, wall_height, arena_size.y))
	_add_wall("WallWest", Vector3(-hx - t * 0.5, y, 0.0), Vector3(t, wall_height, arena_size.y))

func _fit_to_arena() -> void:
	var arena: Node3D = get_parent().get_node_or_null("Arena") as Node3D
	if arena == null:
		push_warning("ArenaWalls: no node named 'Arena' found, using manual size.")
		return
	var have_box: bool = false
	var box: AABB = AABB()
	for m in arena.find_children("*", "MeshInstance3D", true, false):
		var mi: MeshInstance3D = m as MeshInstance3D
		var b: AABB = mi.global_transform * mi.get_aabb()
		if not have_box:
			box = b
			have_box = true
		else:
			box = box.merge(b)
	if not have_box:
		return
	arena_size = Vector2(box.size.x, box.size.z)
	global_position = Vector3(box.get_center().x, box.position.y, box.get_center().z)
	print("[ArenaWalls] fitted. center=", global_position, " size=", arena_size)

func _add_wall(wall_name: String, pos: Vector3, size: Vector3) -> void:
	# Collision
	var shape := BoxShape3D.new()
	shape.size = size
	var cs := CollisionShape3D.new()
	cs.name = wall_name
	cs.shape = shape
	cs.position = pos
	add_child(cs)

	# Visible red surface
	if not show_walls:
		return
	var mesh := BoxMesh.new()
	mesh.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = wall_color
	mat.emission_enabled = true
	mat.emission = Color(wall_color.r, wall_color.g, wall_color.b)
	mat.emission_energy_multiplier = 0.35
	if wall_color.a < 1.0:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mesh.material = mat
	var mi := MeshInstance3D.new()
	mi.name = wall_name + "Mesh"
	mi.mesh = mesh
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
