
extends CharacterBody3D

# MOVEMENT
@export var walk_speed: float = 7.0
@export var sprint_speed: float = 11.0
@export var jump_velocity: float = 10.0
@export var mouse_sensitivity: float = 0.002
@export var slide_speed: float = 14.0
@export var slide_duration: float = 0.6

# CAMERA
@export var normal_fov: float = 75.0

# SHOOTING
@export var shoot_range: float = 200.0
@export var shoot_cooldown: float = 0.8

# HEALTH
var health: int = 100
var spawn_position: Vector3

# INTERNAL VARIABLES
var gravity: float = 18.0
var is_sliding: bool = false
var slide_timer: float = 0.0
var slide_direction: Vector3 = Vector3.ZERO
var shoot_timer: float = 0.0

@onready var camera: Camera3D = $Camera3D


func _ready() -> void:
	add_to_group("player")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	camera.fov = normal_fov
	spawn_position = global_position


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clampf(
			camera.rotation.x,
			deg_to_rad(-85.0),
			deg_to_rad(85.0)
		)

	if event is InputEventMouseButton and event.pressed:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _physics_process(delta: float) -> void:

	# GRAVITY
	if not is_on_floor():
		velocity.y -= gravity * delta

	# JUMP
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	# MOVEMENT INPUT
	var input_dir := Input.get_vector(
		"move_left",
		"move_right",
		"move_forward",
		"move_back"
	)

	var direction := (
		transform.basis * Vector3(input_dir.x, 0, input_dir.y)
	).normalized()

	# SLIDE START
	if Input.is_action_just_pressed("slide") and is_on_floor():
		if not is_sliding and direction.length() > 0.1:
			is_sliding = true
			slide_timer = slide_duration
			slide_direction = direction

	# SLIDE
	if is_sliding:
		slide_timer -= delta
		velocity.x = slide_direction.x * slide_speed
		velocity.z = slide_direction.z * slide_speed

		if slide_timer <= 0.0:
			is_sliding = false

	# NORMAL MOVEMENT
	else:
		var current_speed = walk_speed

		if Input.is_action_pressed("sprint"):
			current_speed = sprint_speed

		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed

	# SHOOTING COOLDOWN
	if shoot_timer > 0.0:
		shoot_timer -= delta

	if Input.is_action_just_pressed("shoot") and shoot_timer <= 0.0:
		shoot()
		shoot_timer = shoot_cooldown

	move_and_slide()


func shoot() -> void:
	var origin = camera.global_position
	var end = origin - camera.global_transform.basis.z * shoot_range

	var query = PhysicsRayQueryParameters3D.create(origin, end)
	query.exclude = [self]

	var result = get_world_3d().direct_space_state.intersect_ray(query)

	if result:
		var target = result["collider"]

		if target.has_method("hit"):
			target.hit()
		elif target.has_method("take_damage"):
			target.take_damage(100)

		print("SHOT HIT: ", target.name)
	else:
		print("SHOT MISSED")


func take_damage(amount: int) -> void:
	health -= amount
	print("PLAYER HEALTH: ", health)

	if health <= 0:
		health = 100
		global_position = spawn_position
		velocity = Vector3.ZERO
		print("PLAYER RESPAWNED")
