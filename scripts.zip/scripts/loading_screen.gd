extends Control
## Fake-but-useful loading screen. Shows a cover and a progress bar for `duration`
## seconds while the next scene preloads in the background, then opens it.

@export var duration: float = 6.0
@export_file("*.tscn") var next_scene: String = "res://scenes/main.tscn"
@export var cover: Texture2D                     # drag your friend's cover image here
@export var loading_text: String = "LOADING"

var _bar: ProgressBar
var _label: Label
var _elapsed: float = 0.0
var _done: bool = false

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_ui()
	ResourceLoader.load_threaded_request(next_scene)

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	if cover != null:
		var pic := TextureRect.new()
		pic.texture = cover
		pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		add_child(pic)

	_label = Label.new()
	_label.add_theme_font_size_override("font_size", 28)
	_label.add_theme_color_override("font_color", Color.WHITE)
	_label.add_theme_color_override("font_outline_color", Color.BLACK)
	_label.add_theme_constant_override("outline_size", 8)
	_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_label.offset_top = -120.0
	_label.offset_bottom = -80.0
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_label)

	_bar = ProgressBar.new()
	_bar.min_value = 0.0
	_bar.max_value = 100.0
	_bar.show_percentage = false
	_bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_bar.offset_left = 80.0
	_bar.offset_right = -80.0
	_bar.offset_top = -70.0
	_bar.offset_bottom = -45.0
	add_child(_bar)

func _process(delta: float) -> void:
	if _done:
		return
	_elapsed += delta
	var t: float = clampf(_elapsed / duration, 0.0, 1.0)
	_bar.value = t * 100.0
	_label.text = loading_text + ".".repeat(int(_elapsed * 2.0) % 4)

	if t >= 1.0:
		var status: int = ResourceLoader.load_threaded_get_status(next_scene)
		if status == ResourceLoader.THREAD_LOAD_LOADED:
			_done = true
			var packed: PackedScene = ResourceLoader.load_threaded_get(next_scene) as PackedScene
			get_tree().change_scene_to_packed(packed)
		elif status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			_done = true
			push_error("LoadingScreen: could not load " + next_scene)
			get_tree().change_scene_to_file(next_scene)
