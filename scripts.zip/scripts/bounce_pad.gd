extends Area3D

@export var launch_speed: float = 18.0
@export var cooldown: float = 0.4

var _last_launch: float = -10.0

func _ready() -> void:
	monitoring = true

func _physics_process(_delta: float) -> void:
	for body in get_overlapping_bodies():
		_try_launch(body)

func _try_launch(body: Node3D) -> void:
	if body.name != "Player":
		return
	var cb := body as CharacterBody3D
	if cb == null:
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - _last_launch < cooldown:
		return
	_last_launch = now
	cb.velocity.y = launch_speed
