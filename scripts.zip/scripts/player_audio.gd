extends Node
## Footsteps, jump and landing sounds. Add as a child Node of the Player (CharacterBody3D).

@export var footstep_sound: AudioStream
@export var jump_sound: AudioStream
@export var land_sound: AudioStream            # optional
@export var footstep_volume_db: float = -6.0
@export var jump_volume_db: float = 0.0
@export var land_volume_db: float = -4.0
@export var min_move_speed: float = 1.5        # horizontal speed needed for footsteps
@export var min_land_speed: float = 6.0        # fall speed needed for a landing sound

var _body: CharacterBody3D
var _foot: AudioStreamPlayer
var _jump: AudioStreamPlayer
var _land: AudioStreamPlayer
var _was_on_floor: bool = true
var _last_vy: float = 0.0

func _ready() -> void:
	_body = get_parent() as CharacterBody3D
	if _body == null:
		push_error("PlayerAudio: this node must be a child of the Player (CharacterBody3D).")
		set_physics_process(false)
		return
	_foot = _make_player(footstep_sound, footstep_volume_db)
	_jump = _make_player(jump_sound, jump_volume_db)
	_land = _make_player(land_sound, land_volume_db)

func _make_player(stream: AudioStream, volume_db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.volume_db = volume_db
	add_child(p)
	return p

func _physics_process(_delta: float) -> void:
	var on_floor: bool = _body.is_on_floor()
	var horizontal_speed: float = Vector2(_body.velocity.x, _body.velocity.z).length()

	# Jump (also plays when a bounce pad launches you)
	if _was_on_floor and not on_floor and _body.velocity.y > 1.0:
		_play(_jump)

	# Landing
	if on_floor and not _was_on_floor and _last_vy < -min_land_speed:
		_play(_land)

	# Footsteps: replays while you move on the ground, stops in the air or when still
	if on_floor and horizontal_speed > min_move_speed:
		if not _foot.playing and footstep_sound != null:
			_foot.play()
	elif _foot.playing:
		_foot.stop()

	_was_on_floor = on_floor
	_last_vy = _body.velocity.y

func _play(p: AudioStreamPlayer) -> void:
	if p.stream != null:
		p.play()
