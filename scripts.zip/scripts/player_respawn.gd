extends Node
## Death + respawn for the player. Add as a child Node of the Player (CharacterBody3D).
## Enemies call die() when they touch you. Respawn gets slower with deaths and time.
## Falling off the map puts you back at your start point.

@export var base_respawn_delay: float = 1.5
@export var delay_per_death: float = 0.4
@export var delay_per_minute: float = 0.5
@export var max_respawn_delay: float = 5.0
@export var invulnerable_time: float = 2.0   # protection after respawning
@export var clear_radius: float = 12.0       # enemies this close to your spawn are removed on respawn
@export var fall_depth: float = 20.0         # falling this far below your start puts you back
@export var fall_counts_as_death: bool = false
@export var fall_protection_time: float = 1.0

var deaths: int = 0

var _body: CharacterBody3D
var _spawn_pos: Vector3
var _spawn_rot: Vector3
var _original_mode: Node.ProcessMode
var _dead: bool = false
var _invuln_until: float = 0.0
var _start_time: float = 0.0
var _overlay: Control
var _msg_label: Label
var _deaths_label: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("player_respawn")
	_body = get_parent() as CharacterBody3D
	if _body == null:
		push_error("PlayerRespawn: must be a child of the Player (CharacterBody3D).")
		return
	_spawn_pos = _body.global_position
	_spawn_rot = _body.rotation
	_original_mode = _body.process_mode
	_start_time = Time.get_ticks_msec() / 1000.0
	_build_ui()
	_invuln_until = _start_time + 4.0

func _physics_process(_delta: float) -> void:
	if _body == null or _dead:
		return
	if _body.global_position.y < _spawn_pos.y - fall_depth:
		if fall_counts_as_death:
			_invuln_until = 0.0
			die()
		else:
			_teleport_back()

func _teleport_back() -> void:
	_body.global_position = _spawn_pos
	_body.rotation = _spawn_rot
	_body.velocity = Vector3.ZERO
	_invuln_until = Time.get_ticks_msec() / 1000.0 + fall_protection_time

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 15
	add_child(layer)

	_overlay = Control.new()
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.visible = false
	layer.add_child(_overlay)

	var tint := ColorRect.new()
	tint.color = Color(0.6, 0.0, 0.0, 0.45)
	tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.add_child(tint)

	_msg_label = _make_label(56)
	_msg_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_overlay.add_child(_msg_label)

	_deaths_label = _make_label(24)
	_deaths_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_deaths_label.offset_left = -220.0
	_deaths_label.offset_top = 14.0
	_deaths_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_deaths_label.text = "DEATHS: 0"
	layer.add_child(_deaths_label)

func _make_label(font_size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

## Called by enemies on contact.
func die() -> void:
	if _dead or _body == null:
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now < _invuln_until:
		return
	_dead = true
	deaths += 1
	_deaths_label.text = "DEATHS: %d" % deaths

	var minutes: float = (now - _start_time) / 60.0
	var delay: float = clampf(
		base_respawn_delay + float(deaths - 1) * delay_per_death + minutes * delay_per_minute,
		base_respawn_delay, max_respawn_delay)

	_body.velocity = Vector3.ZERO
	_body.process_mode = Node.PROCESS_MODE_DISABLED   # freezes movement, aiming and shooting
	_overlay.visible = true

	var left: float = delay
	while left > 0.0:
		_msg_label.text = "YOU DIED\nRespawning in %.1f" % left
		var step: float = minf(0.1, left)
		await get_tree().create_timer(step).timeout
		left -= step

	_respawn()

func _respawn() -> void:
	_body.global_position = _spawn_pos
	_body.rotation = _spawn_rot
	_body.velocity = Vector3.ZERO
	_body.process_mode = _original_mode
	for e in get_tree().get_nodes_in_group("enemy"):
		var n: Node3D = e as Node3D
		if n != null and n.global_position.distance_to(_spawn_pos) < clear_radius:
			n.queue_free()   # the manager replaces them shortly
	_overlay.visible = false
	_invuln_until = Time.get_ticks_msec() / 1000.0 + invulnerable_time
	_dead = false
