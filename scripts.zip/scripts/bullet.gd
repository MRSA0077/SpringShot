extends Node3D
## Visible sniper bullet. Created in code by sniper_gun.gd (no scene file needed).
## Sweeps a ray each physics frame so fast bullets never tunnel through targets.

const MAX_LIFETIME: float = 3.0

static var _mesh: CapsuleMesh = null

var _velocity: Vector3 = Vector3.ZERO
var _exclude: Array[RID] = []
var _life: float = MAX_LIFETIME

func setup(dir: Vector3, speed: float, exclude: Array[RID]) -> void:
	_velocity = dir.normalized() * speed
	_exclude = exclude.duplicate()
	var target: Vector3 = global_position + dir
	if not dir.is_equal_approx(Vector3.UP) and not dir.is_equal_approx(Vector3.DOWN):
		look_at(target, Vector3.UP)

func _ready() -> void:
	if _mesh == null:
		_mesh = CapsuleMesh.new()
		_mesh.radius = 0.04
		_mesh.height = 0.6
		_mesh.radial_segments = 8
		_mesh.rings = 2
		var mat := StandardMaterial3D.new()
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.albedo_color = Color(1.0, 0.85, 0.2)
		_mesh.material = mat
	var mi := MeshInstance3D.new()
	mi.mesh = _mesh
	mi.rotation_degrees = Vector3(90.0, 0.0, 0.0) # capsule points along -Z
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

func _physics_process(delta: float) -> void:
	var from: Vector3 = global_position
	var to: Vector3 = from + _velocity * delta
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var excl: Array[RID] = _exclude.duplicate()

	for i in 4:
		var query := PhysicsRayQueryParameters3D.create(from, to)
		query.exclude = excl
		query.collide_with_areas = true
		var result: Dictionary = space.intersect_ray(query)
		if result.is_empty():
			break
		var collider: Object = result["collider"]
		var hittable: Node = _find_hittable(collider)
		if hittable != null:
			hittable.hit()
			get_tree().call_group("score_keeper", "add_points")
			queue_free()
			return
		if collider is Area3D:
			excl.append(result["rid"]) # ignore trigger areas such as the bounce pad
			continue
		queue_free() # hit a wall or floor
		return

	global_position = to
	_life -= delta
	if _life <= 0.0:
		queue_free()

func _find_hittable(obj: Object) -> Node:
	var n: Node = obj as Node
	while n != null:
		if n.has_method("hit"):
			return n
		n = n.get_parent()
	return null
