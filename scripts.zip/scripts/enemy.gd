extends CharacterBody3D
## Chases the player. Touching the player kills them. Gets tougher via setup()/update_difficulty().

signal died

@export var base_speed: float = 3.0
@export var max_speed: float = 7.0
@export var base_health: int = 2
@export var extra_health_at_max: int = 3     # health added at full difficulty
@export var turn_speed: float = 6.0
@export var kill_distance: float = 1.4       # touching the player within this range kills them
@export var kill_score: int = 50             # points for killing this enemy
@export var fall_reset_depth: float = 40.0

var _speed: float = 3.0
var _health: int = 2
var _dead: bool = false
var _player: Node3D = null
var _start_pos: Vector3 = Vector3.ZERO
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready() -> void:
	add_to_group("enemy")
	_start_pos = global_position
	_speed = base_speed
	_health = base_health
	_find_player()

func _find_player() -> void:
	_player = get_tree().current_scene.get_node_or_null("Player") as Node3D
	var body := _player as CollisionObject3D
	if body != null:
		add_collision_exception_with(body)        # no pushing or standing on each other
		body.add_collision_exception_with(self)

## Called once by the manager when it spawns this enemy. d = 0..1
func setup(d: float) -> void:
	_speed = lerpf(base_speed, max_speed, d)
	_health = base_health + roundi(d * float(extra_health_at_max))

## Called regularly so enemies already alive speed up as the match goes on.
func update_difficulty(d: float) -> void:
	_speed = lerpf(base_speed, max_speed, d)

func _physics_process(delta: float) -> void:
	if _player == null:
		_find_player()
	if not is_on_floor():
		velocity.y -= _gravity * delta

	var dir: Vector3 = Vector3.ZERO
	if _player != null:
		var to_player: Vector3 = _player.global_position - global_position
		var flat: Vector3 = Vector3(to_player.x, 0.0, to_player.z)
		var dist: float = flat.length()
		if dist > 0.01:
			dir = flat / dist
			# face the player (model assumed to face -Z; if it looks backwards, use atan2(dir.x, dir.z))
			var target_yaw: float = atan2(-dir.x, -dir.z)
			rotation.y = lerp_angle(rotation.y, target_yaw, clampf(turn_speed * delta, 0.0, 1.0))
		if dist < kill_distance and absf(to_player.y) < 2.5:
			get_tree().call_group("player_respawn", "die")

	velocity.x = dir.x * _speed
	velocity.z = dir.z * _speed
	move_and_slide()

	if global_position.y < _start_pos.y - fall_reset_depth:
		global_position = _start_pos
		velocity = Vector3.ZERO

## Called by bullets.
func hit() -> void:
	if _dead:
		return
	_health -= 1
	if _health <= 0:
		_dead = true
		get_tree().call_group("score_keeper", "add_points", kill_score)
		died.emit()
		queue_free()
