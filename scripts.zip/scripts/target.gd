
extends StaticBody3D

func hit() -> void:
	print("TARGET HIT!")
	queue_free()
