extends Node3D
## Keeps `target_count` colorful floating balls alive at random spots inside the arena.
## Each shot ball is replaced after `respawn_delay`. Independent of target.gd.

const TargetBall = preload("res://scripts/target_ball.gd")

@export var target_count: int = 10
@export var respawn_delay: float = 1.0
@export var min_height: float = 1.2        # lowest a ball floats above a surface
@export var max_height: float = 4.0        # highest a ball floats above a surface
@export var min_radius: float = 0.45
@export var max_radius: float = 0.7
@export var edge_margin: float = 3.0       # keep this far from the walls
@export var min_spacing: float = 3.0       # minimum distance between balls
@export var existing_target_names: Array[String] = ["Target", "Target2", "Target3"]
@export var debug_prints: bool = true

var _center: Vector3 = Vector3.ZERO
var _half: Vector2 = Vector2(15.0, 15.0)
var _top_y: float = 20.0
var _bottom_y: float = -20.0
var _balls: Array[Node3D] = []
var _colors: Array[Color] = [
	Color(1.0, 0.25, 0.25), Color(1.0, 0.6, 0.1), Color(1.0, 0.9, 0.1),
	Color(0.2, 1.0, 0.4), Color(0.2, 0.7, 1.0), Color(0.8, 0.3, 1.0),
	Color(1.0, 0.4, 0.8),
]

func _ready() -> void:
	var main: Node = get_parent()
	# Remove your old hand-placed targets (their average position is the fallback center)
	var sum: Vector3 = Vector3.ZERO
	var found: int = 0
	for n in existing_target_names:
		var node: Node3D = main.get_node_or_null(n) as Node3D
		if node != null:
			sum += node.global_position
			found += 1
			node.queue_free()
	var fallback: Vector3 = sum / float(found) if found > 0 else Vector3.ZERO
	_read_bounds(main, fallback)

	# Wait so floor, furniture and walls are registered with the physics engine
	await get_tree().physics_frame
	await get_tree().physics_frame
	for i in target_count:
		_spawn_one()
	if debug_prints:
		print("[Spawner] spawned ", _balls.size(), " targets. center=", _center, " half=", _half)

func _read_bounds(main: Node, fallback: Vector3) -> void:
	var walls: Node3D = main.get_node_or_null("ArenaWalls") as Node3D
	if walls != null:
		var size: Variant = walls.get("arena_size")
		if size is Vector2:
			var s: Vector2 = size as Vector2
			_center = walls.global_position
			_half = Vector2(maxf(s.x * 0.5 - edge_margin, 1.0), maxf(s.y * 0.5 - edge_margin, 1.0))
			var h: Variant = walls.get("wall_height")
			var wall_h: float = float(h) if h is float else 20.0
			_top_y = _center.y + wall_h
			_bottom_y = _center.y - 3.0
			return
	# No ArenaWalls found: fall back to the area around your old targets
	_center = fallback
	_half = Vector2(15.0, 15.0)
	_top_y = fallback.y + 20.0
	_bottom_y = fallback.y - 20.0

func _pick_position() -> Vector3:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	for attempt in 25:
		var x: float = randf_range(_center.x - _half.x, _center.x + _half.x)
		var z: float = randf_range(_center.z - _half.y, _center.z + _half.y)
		var query := PhysicsRayQueryParameters3D.create(Vector3(x, _top_y, z), Vector3(x, _bottom_y, z))
		query.collision_mask = 1
		query.collide_with_areas = false
		var result: Dictionary = space.intersect_ray(query)
		if result.is_empty():
			continue
		var p: Vector3 = (result["position"] as Vector3) + Vector3(0.0, randf_range(min_height, max_height), 0.0)
		if p.y > _top_y - 1.0:
			continue
		if _far_from_others(p) and _is_free(p):
			return p
	return Vector3(_center.x, _center.y + 2.0, _center.z)

func _far_from_others(p: Vector3) -> bool:
	for b in _balls:
		if is_instance_valid(b) and b.global_position.distance_to(p) < min_spacing:
			return false
	return true

func _is_free(p: Vector3) -> bool:
	var shape := SphereShape3D.new()
	shape.radius = 0.7
	var params := PhysicsShapeQueryParameters3D.new()
	params.shape = shape
	params.transform = Transform3D(Basis(), p)
	params.collision_mask = 1
	params.collide_with_areas = false
	return get_world_3d().direct_space_state.intersect_shape(params, 1).is_empty()

func _spawn_one() -> void:
	if not is_inside_tree():
		return
	var ball := TargetBall.new()
	ball.setup(randf_range(min_radius, max_radius), _colors.pick_random())
	add_child(ball)
	ball.global_position = _pick_position()
	ball.shot.connect(_on_ball_shot.bind(ball))
	_balls.append(ball)

func _on_ball_shot(ball: Node3D) -> void:
	_balls.erase(ball)
	get_tree().create_timer(respawn_delay).timeout.connect(_spawn_one)
