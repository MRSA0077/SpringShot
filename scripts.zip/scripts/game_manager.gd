extends Node
## Score + countdown timer + high score modal. Child Node of the Main scene root.
## Builds its own HUD in code, so it depends on no existing nodes.

@export var round_time: float = 120.0
@export var points_per_target: int = 10
@export_file("*.tscn") var menu_scene: String = "res://ui/menu_screen.tscn"

const GOLD: Color = Color(1.0, 0.85, 0.2)
const RED: Color = Color(1.0, 0.3, 0.3)

var score: int = 0
var time_left: float = 0.0
var _best: int = 0
var _over: bool = false
var _pop_tween: Tween

var _score_label: Label
var _best_label: Label
var _timer_label: Label

var _modal: Control
var _modal_title: Label
var _modal_score: Label
var _modal_best: Label
var _modal_record: Label
var _again_btn: Button

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS # keeps working while the game is paused
	add_to_group("score_keeper")
	time_left = round_time
	_best = SaveData.get_best()
	_build_hud()
	_build_modal()
	_refresh()

# ---------------------------------------------------------------- HUD
func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	_score_label = _make_label(34, Color.WHITE)
	_score_label.position = Vector2(24.0, 14.0)
	layer.add_child(_score_label)

	_best_label = _make_label(22, Color(0.85, 0.85, 0.85))
	_best_label.position = Vector2(24.0, 58.0)
	layer.add_child(_best_label)

	_timer_label = _make_label(36, Color.WHITE)
	_timer_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_timer_label.offset_top = 14.0
	_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layer.add_child(_timer_label)

# ------------------------------------------------------------- Modal
func _build_modal() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)

	_modal = Control.new()
	_modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.mouse_filter = Control.MOUSE_FILTER_STOP
	_modal.visible = false
	layer.add_child(_modal)

	var dim := ColorRect.new()
	dim.color = Color(0.0, 0.0, 0.0, 0.65)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_modal.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.add_child(center)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.07, 0.11, 0.96)
	sb.set_corner_radius_all(18)
	sb.set_border_width_all(4)
	sb.border_color = Color(0.9, 0.15, 0.15)
	sb.set_content_margin_all(40.0)
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)

	_modal_title = _make_label(56, Color.WHITE)
	_modal_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_modal_title)

	_modal_score = _make_label(40, Color.WHITE)
	_modal_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_modal_score)

	_modal_record = _make_label(34, GOLD)
	_modal_record.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_modal_record)

	_modal_best = _make_label(28, Color(0.85, 0.85, 0.85))
	_modal_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_modal_best)

	_again_btn = _make_button("PLAY AGAIN   (R)")
	_again_btn.pressed.connect(_restart)
	box.add_child(_again_btn)

	var menu_btn: Button = _make_button("MAIN MENU   (M)")
	menu_btn.pressed.connect(_go_menu)
	box.add_child(menu_btn)

func _make_label(font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _make_button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320.0, 56.0)
	b.add_theme_font_size_override("font_size", 24)
	return b

# ----------------------------------------------------------- Gameplay
func add_points(amount: int = 0) -> void:
	if _over:
		return
	score += amount if amount > 0 else points_per_target
	_refresh()
	_pop()

func _pop() -> void:
	if _pop_tween != null and _pop_tween.is_valid():
		_pop_tween.kill()
	_score_label.pivot_offset = Vector2(0.0, _score_label.size.y * 0.5)
	_score_label.scale = Vector2(1.25, 1.25)
	_pop_tween = create_tween()
	_pop_tween.tween_property(_score_label, "scale", Vector2.ONE, 0.15)

func _process(delta: float) -> void:
	if _over:
		return
	time_left -= delta
	if time_left <= 0.0:
		time_left = 0.0
		_end_round()
	_refresh()

func _refresh() -> void:
	_score_label.text = "SCORE: %d" % score

	if _best > 0 and score > _best:
		_best_label.text = "NEW RECORD!"
		_best_label.add_theme_color_override("font_color", GOLD)
	else:
		_best_label.text = "BEST: %d" % _best
		_best_label.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))

	var secs: int = int(ceil(time_left))
	_timer_label.text = "%d:%02d" % [floori(float(secs) / 60.0), secs % 60]
	_timer_label.add_theme_color_override("font_color", RED if secs <= 10 else Color.WHITE)

# -------------------------------------------------------------- End
func _end_round() -> void:
	_over = true
	var previous_best: int = _best
	var is_record: bool = SaveData.submit(score)
	if is_record:
		_best = score

	_modal_title.text = "TIME UP!"
	_modal_score.text = "SCORE: %d" % score
	if is_record:
		_modal_record.text = "NEW HIGH SCORE!"
		_modal_best.text = "Previous best: %d" % previous_best
	else:
		_modal_record.text = ""
		_modal_best.text = "BEST: %d" % _best
	_modal_record.visible = is_record

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_modal.visible = true
	_again_btn.grab_focus()
	get_tree().paused = true

func _unhandled_input(event: InputEvent) -> void:
	if not _over:
		return
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_R:
			_restart()
		elif event.keycode == KEY_M:
			_go_menu()

func _restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _go_menu() -> void:
	if ResourceLoader.exists(menu_scene):
		get_tree().paused = false
		get_tree().change_scene_to_file(menu_scene)
