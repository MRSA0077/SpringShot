extends Node3D
## Keeps enemies alive and ramps up difficulty over time.
## Add as a child Node3D of Main, then drag your enemy scene into "Enemy Scene".

@export var enemy_scene: PackedScene
@export var start_count: int = 1
@export var max_count: int = 5
@export var seconds_per_extra_enemy: float = 25.0
@export var ramp_seconds: float = 120.0        # time until full difficulty
@export var respawn_delay_start: float = 4.0   # seconds before an enemy returns (early game)
@export var respawn_delay_min: float = 1.0     # ... and at full difficulty
@export var min_player_distance: float = 18.0  # enemies spawn at least this far from you
@export var edge_margin: float = 3.0
@export var debug_prints: bool = true

var _elapsed: float = 0.0
var _alive: Array[Node3D] = []
var _pending: int = 0
var _tick: float = 0.0
var _center: Vector3 = Vector3.ZERO
var _half: Vector2 = Vector2(15.0, 15.0)
var _top_y: float = 20.0
var _bottom_y: float = -20.0

func _ready() -> void:
	if enemy_scene == null:
		push_error("EnemyManager: drag your enemy scene into the Enemy Scene slot.")
		set_process(false)
		return
	_read_bounds()
	# Remove any hand-placed enemies; the manager owns them from now on
	await get_tree().process_frame
	for e in get_tree().get_nodes_in_group("enemy"):
		if e.get_parent() != self:
			e.queue_free()

func _read_bounds() -> void:
	var walls: Node3D = get_parent().get_node_or_null("ArenaWalls") as Node3D
	if walls == null:
		return
	var size: Variant = walls.get("arena_size")
	if size is Vector2:
		var s: Vector2 = size as Vector2
		_center = walls.global_position
		_half = Vector2(maxf(s.x * 0.5 - edge_margin, 1.0), maxf(s.y * 0.5 - edge_margin, 1.0))
		var h: Variant = walls.get("wall_height")
		_top_y = _center.y + (float(h) if h is float else 20.0)
		_bottom_y = _center.y - 3.0

func _difficulty() -> float:
	return clampf(_elapsed / ramp_seconds, 0.0, 1.0)

func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed < 6.0:
		return
	var d: float = _difficulty()

	# Forget dead or freed enemies
	var still: Array[Node3D] = []
	for e in _alive:
		if is_instance_valid(e) and not e.is_queued_for_deletion():
			still.append(e)
	_alive = still

	# Top up to the current target count
	var target: int = clampi(start_count + int(_elapsed / seconds_per_extra_enemy), start_count, max_count)
	var missing: int = target - _alive.size() - _pending
	for i in maxi(missing, 0):
		_pending += 1
		get_tree().create_timer(lerpf(respawn_delay_start, respawn_delay_min, d)).timeout.connect(_on_spawn_timer)

	# Enemies already alive get faster as time passes
	_tick -= delta
	if _tick <= 0.0:
		_tick = 1.0
		for e in _alive:
			e.call("update_difficulty", d)

func _on_spawn_timer() -> void:
	_pending = maxi(_pending - 1, 0)
	_spawn_one()

func _spawn_one() -> void:
	var e: Node3D = enemy_scene.instantiate() as Node3D
	if e == null:
		push_error("EnemyManager: enemy scene root must be a Node3D/CharacterBody3D.")
		return
	add_child(e)
	e.global_position = _pick_position()
	e.call("setup", _difficulty())
	_alive.append(e)
	if debug_prints:
		print("[EnemyManager] spawned enemy at ", e.global_position, "  alive=", _alive.size(), "  difficulty=", snappedf(_difficulty(), 0.01))

func _pick_position() -> Vector3:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var player: Node3D = get_parent().get_node_or_null("Player") as Node3D
	for attempt in 30:
		var x: float = randf_range(_center.x - _half.x, _center.x + _half.x)
		var z: float = randf_range(_center.z - _half.y, _center.z + _half.y)
		var q := PhysicsRayQueryParameters3D.create(Vector3(x, _top_y, z), Vector3(x, _bottom_y, z))
		q.collision_mask = 1
		q.collide_with_areas = false
		var r: Dictionary = space.intersect_ray(q)
		if r.is_empty() or r["collider"] is CharacterBody3D:
			continue
		var p: Vector3 = (r["position"] as Vector3) + Vector3(0.0, 0.6, 0.0)
		if player != null and p.distance_to(player.global_position) < min_player_distance:
			continue
		return p
	return Vector3(_center.x, _center.y + 3.0, _center.z)
