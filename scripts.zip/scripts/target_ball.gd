extends StaticBody3D
## A shootable floating ball. Built entirely in code by target_spawner.gd.
## Your bullet calls hit(), which removes the ball and tells the spawner to make a new one.

signal shot

var _dead: bool = false
var _time: float = randf() * TAU
var _base_y: float = 0.0
var _has_base: bool = false

func setup(radius: float, color: Color) -> void:
	collision_layer = 2   # the player (layer 1) walks through it, bullets still hit it
	collision_mask = 0

	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 16
	mesh.rings = 8
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 1.0
	mesh.material = mat
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

	var shape := SphereShape3D.new()
	shape.radius = radius
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _process(delta: float) -> void:
	if not _has_base:
		_base_y = position.y
		_has_base = true
	_time += delta * 1.5
	position.y = _base_y + sin(_time) * 0.15   # gentle bobbing

func hit() -> void:
	if _dead:
		return
	_dead = true
	shot.emit()
	queue_free()
