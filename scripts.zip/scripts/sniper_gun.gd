extends Node3D
## Attach to the WeaponHolder node (inside player.tscn).
## Hold left mouse to fire visible bullets. Includes recoil and optional shot sound.

const BulletScript = preload("res://scripts/bullet.gd")

@export var bullet_speed: float = 150.0
@export var fire_cooldown: float = 0.12          # seconds between shots
@export var automatic: bool = true               # hold to keep firing
@export var muzzle_offset: Vector3 = Vector3(0.25, -0.2, -0.8) # relative to camera
@export var recoil_back: float = 0.06            # gun kicks back this far
@export var recoil_pitch_deg: float = 3.0        # gun tilts up this much
@export var recoil_recovery: float = 14.0        # how fast it settles
@export var shoot_sound: AudioStream             # drag a .wav/.ogg here (optional)
@export var shoot_volume_db: float = 0.0

var _cooldown: float = 0.0
var _exclude: Array[RID] = []
var _rest_pos: Vector3
var _rest_rot: Vector3
var _sfx: AudioStreamPlayer

func _ready() -> void:
	_rest_pos = position
	_rest_rot = rotation
	var n: Node = get_parent()
	while n != null:
		if n is CollisionObject3D:
			_exclude.append((n as CollisionObject3D).get_rid())
		n = n.get_parent()
	if shoot_sound != null:
		_sfx = AudioStreamPlayer.new()
		_sfx.stream = shoot_sound
		_sfx.volume_db = shoot_volume_db
		_sfx.max_polyphony = 6
		add_child(_sfx)

func _physics_process(delta: float) -> void:
	_cooldown = maxf(_cooldown - delta, 0.0)
	var k: float = clampf(recoil_recovery * delta, 0.0, 1.0)
	position = position.lerp(_rest_pos, k)
	rotation = rotation.lerp(_rest_rot, k)
	if automatic and _cooldown <= 0.0 and Input.is_action_pressed("shoot") \
			and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_fire()

func _unhandled_input(event: InputEvent) -> void:
	if not automatic and event.is_action_pressed("shoot") and _cooldown <= 0.0:
		_fire()

func _fire() -> void:
	var cam: Camera3D = get_viewport().get_camera_3d()
	if cam == null:
		return
	_cooldown = fire_cooldown

	var origin: Vector3 = cam.global_position
	var forward: Vector3 = -cam.global_transform.basis.z
	var far_point: Vector3 = origin + forward * 500.0
	var query := PhysicsRayQueryParameters3D.create(origin, far_point)
	query.exclude = _exclude
	var hit: Dictionary = cam.get_world_3d().direct_space_state.intersect_ray(query)
	var aim_point: Vector3 = hit["position"] if not hit.is_empty() else far_point

	var muzzle: Vector3 = cam.global_transform * muzzle_offset
	var dir: Vector3 = (aim_point - muzzle).normalized()

	var bullet := BulletScript.new()
	get_tree().current_scene.add_child(bullet)
	bullet.global_position = muzzle
	bullet.setup(dir, bullet_speed, _exclude)

	# Recoil kick
	position.z += recoil_back
	rotation.x += deg_to_rad(recoil_pitch_deg)
	if _sfx != null:
		_sfx.play()
